import 'package:flutter/material.dart';

/// App-wide color constants for Siva Saravana Chits
class AppColors {
  // Brand Green Colors
  static const Color primary = Color(0xFF018F46);
  static const Color primaryDark = Color(0xFF002914);
  static const Color greenLight = Color(0xFF00B050);

  // Gradient Colors for Header
  static const Color gradientTop = Color(0xFF002914);
  static const Color gradientBottom = Color(0xFF018F46);

  // Rating & Accent Colors
  static const Color starGold = Color(0xFFFFB800);

  // Text Colors
  static const Color textPrimary = Color(0xFF1E1E1E);
  static const Color textSecondary = Color(0xFF4A4A4A);
  static const Color textWhite = Color(0xFFFFFFFF);
  static const Color textLightGray = Color(0xFF6B7280);

  // UI Element Colors
  static const Color background = Color(0xFFFFFFFF);
  static const Color buttonBackground = Color(0xFF018F46);
  static const Color circleBackground = Color(0xFFFFFFFF);
}
