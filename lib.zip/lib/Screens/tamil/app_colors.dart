import 'package:flutter/material.dart';

/// Centralized UI color configuration file.
/// Modify any color here to update the look and feel across the entire app.
class AppColors {
  // Primary Green accents (Chit Value text, Active tab text & indicator)
  static Color primaryGreen = const Color(0xFF018F46);

  // Tab Colors
  static Color tabActiveBg = const Color(0xFFCAFFE4);
  static Color tabActiveText = const Color(0xFF018F46);
  static Color tabInactiveBg = Colors.white;
  static Color tabInactiveText = const Color(0xFF657371);
  static Color tabUnderline = const Color(0xFF018F46);

  // App Bar & Header Colors
  static Color appBarBg = Color(0xFFF3F3F5);
  static Color titleText = const Color(0xFF1E293B);
  static Color backIconColor = const Color(0xFF1E293B);
  
  // Need Help Pill Button
  static Color helpButtonBorder = const Color(0xFFCBD5E1);
  static Color helpButtonText = const Color(0xFF2ECC71);
  static Color helpButtonBg = Colors.white;

  // Table Colors
  static Color tableHeaderBg = const Color(0xFFFAFAFA);
  static Color tableHeaderText = const Color(0xFF475569);
  static Color rowText = const Color(0xFF334155);
  static Color dividerColor = const Color(0xFFE2E8F0);

  // General Background
  static Color scaffoldBg = Color(0xFFF3F3F5);
}
