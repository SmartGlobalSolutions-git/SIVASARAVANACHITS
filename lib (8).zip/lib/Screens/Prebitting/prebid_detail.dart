import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:siva_saravana/Screens/Home_Sections/need_help_screen.dart';
import 'package:siva_saravana/Screens/Home_Sections/notification_screen.dart';
import 'package:siva_saravana/Screens/Prebitting/terms_condition.dart';
import 'package:siva_saravana/constants/app_colors.dart';
import '../../services/prebid_api.dart';
import '../../services/profile_view_api.dart';
import '../Home_Sections/drawers_screen.dart';
import '../../services/translation_service.dart';

const Color kScreenBg = Color(0xFFF3F3F5);
const Color kAuctionCardBg = Color(0xFFFFFCF0);
const Color kAuctionCardBorder = Color(0xFFE2E5E8);
const Color kLabelGrey = Color(0xFF64748B);
const Color kValueDark = Color(0xFF0F172A);
const Color kTodayBg = Color(0xFFD1FAE5);
const Color kTodayText = Color(0xFF047857);
const Color kAmountGreen = Color(0xFF018F46);
const Color kClosesRed = Color(0xFFBA1111);
const Color kTimerBoxBg = Color(0xFF22378A);
const Color kTimerBoxBorder = Color(0xFF10B981);
const Color kHeadingDark = Color(0xFF1A1C1C);
const Color kInputLabelBrown = Color(0xFF4D4732);
const Color kInputBg = Color(0xFFF9F9F9);
const Color kInputBorder = Color(0xFF7BE6AF);
const Color kTermsCardBg = Color(0xFFFFFFFF);
const Color kTermsCardBorder = Color(0xFFD0C6AB);
const Color kCheckboxGreen = Color(0xFF018F46);

// ----------------------------------------------------------------------
// SCREEN
// ----------------------------------------------------------------------
class PrebiddingDetailScreen extends StatefulWidget {
  final String groupName;
  final String groupCode;
  final DateTime auctionDateTime;
  final double lastAuctionAmount;
  final double minBid;
  final double maxBid;
  final String chitId;
  final String grpId;
  final VoidCallback? onBackTap;
  final VoidCallback? onMenuTap;

  const PrebiddingDetailScreen({
    super.key,
    required this.groupName,
    required this.groupCode,
    required this.auctionDateTime,
    required this.lastAuctionAmount,
    this.minBid = 5000,
    this.maxBid = 300000,
    this.chitId = '',
    this.grpId = '',
    this.onBackTap,
    this.onMenuTap,
  });

  @override
  State<PrebiddingDetailScreen> createState() =>
      _PrebiddingDetailScreenState();
}

class _PrebiddingDetailScreenState extends State<PrebiddingDetailScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  bool _isDrawerOpen = false;
  late final TextEditingController _amountController;
  bool _agreedToTerms = true;
  Timer? _timer;
  Duration _remaining = Duration.zero;
  Map<String, dynamic>? _apiData;
  bool _isLoading = true;
  String _bidderName = '';

  @override
  void initState() {
    super.initState();
    _amountController = TextEditingController();
    _fetchDetails();
    _fetchProfile();
  }

  Future<void> _fetchProfile() async {
    final response = await ProfileViewApiService.fetchProfile();
    if (mounted && response != null && response['error'] == false && response['profile'] != null) {
      setState(() {
        _bidderName = response['profile']['name']?.toString() ?? '';
      });
    }
  }

  Future<void> _fetchDetails() async {
    final response = await PrebidApiService.fetchPrebidDetail(widget.chitId, widget.grpId);
    if (mounted) {
      setState(() {
        _apiData = response;
        _isLoading = false;
        _tick();
        _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
      });
    }
  }

  void _tick() {
    if (_apiData != null && _apiData!['auction_datetime'] != null && _apiData!['auction_datetime'].toString().isNotEmpty) {
      try {
        final auctionTime = DateTime.parse(_apiData!['auction_datetime'].toString());
        final diff = auctionTime.difference(DateTime.now());
        setState(() {
          _remaining = diff.isNegative ? Duration.zero : diff;
        });
      } catch (e) {
        setState(() {
          _remaining = Duration.zero;
        });
      }
    } else {
      setState(() {
        _remaining = Duration.zero;
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _amountController.dispose();
    super.dispose();
  }

  String _formatAmount(double v) {
    final bool isNegative = v < 0;
    final String s = v.abs().toInt().toString();
    final reversed = s.split('').reversed.toList();
    final buffer = StringBuffer();
    for (int i = 0; i < reversed.length; i++) {
      if (i != 0 && i % 3 == 0) buffer.write(',');
      buffer.write(reversed[i]);
    }
    final String result = buffer.toString().split('').reversed.join();
    return isNegative ? '-$result' : result;
  }

  String _formatDate(DateTime d) {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    ];
    return "${d.day.toString().padLeft(2, '0')} ${months[d.month - 1]} ${d.year}";
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !_isDrawerOpen,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        if (_isDrawerOpen) {
          _scaffoldKey.currentState?.closeDrawer();
        }
      },
      child: Scaffold(
        key: _scaffoldKey,
        backgroundColor: kScreenBg,
        onDrawerChanged: (isOpened) {
          if (widget.onMenuTap == null) {
            setState(() {
              _isDrawerOpen = isOpened;
            });
          }
        },
        drawer: widget.onMenuTap == null ? const DrawersScreen() : null,
        appBar: _buildAppBar(context),
        body: _isLoading 
            ? const Center(child: CircularProgressIndicator()) 
            : SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(16.w, 25.h, 16.w, 24.h),
                child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildCountdownRow(),
                  SizedBox(height: 24.h),
                  _buildAuctionDetailsCard(),
                  SizedBox(height: 16.h),
                  _buildRunningBalanceCard(),
                  SizedBox(height: 24.h),
                  TrText(
                    'Pre-Bid Details',
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontWeight: FontWeight.w700,
                      fontSize: 16.sp,
                      color: kHeadingDark,
                    ),
                  ),
                  SizedBox(height: 12.h),
                  TrText(
                    'Enter Pre-Bid Amount',
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontWeight: FontWeight.w400,
                      fontSize: 14.sp,
                      color: kInputLabelBrown,
                    ),
                  ),
                  SizedBox(height: 8.h),
                  _buildAmountInput(),
                  SizedBox(height: 6.h),
                  Wrap(
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      TrText(
                        'Enter amount between',
                        style: TextStyle(
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w400,
                          fontSize: 12.sp,
                          color: kInputLabelBrown,
                        ),
                      ),
                      Text(
                        ' ₹${_formatAmount(widget.minBid)} ',
                        style: TextStyle(
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w600,
                          fontSize: 12.sp,
                          color: kInputLabelBrown,
                        ),
                      ),
                      TrText(
                        'and',
                        style: TextStyle(
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w400,
                          fontSize: 12.sp,
                          color: kInputLabelBrown,
                        ),
                      ),
                      Text(
                        ' ₹${_formatAmount(widget.maxBid)}',
                        style: TextStyle(
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w600,
                          fontSize: 12.sp,
                          color: kInputLabelBrown,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 24.h),
                  _buildTermsCard(context),
                ],
              ),
            ),
      ),
    );
  }

  // ---------------------------- APP BAR ----------------------------
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      scrolledUnderElevation: 0,
      surfaceTintColor: Colors.transparent,
      titleSpacing: 0,
      leading: IconButton(
        icon: Icon(Icons.menu, color: Colors.black, size: 24.sp),
        onPressed: () {
          if (widget.onMenuTap != null) {
            widget.onMenuTap!();
          } else {
            _scaffoldKey.currentState?.openDrawer();
          }
        },
      ),
      title: TrText(
        'Prebidding',
        style: TextStyle(
          fontFamily: 'Inter',
          fontWeight: FontWeight.w600,
          fontSize: 16.sp,
          color: Colors.black,
        ),
      ),
      actions: [
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const NeedHelpScreen()),
              );
            },
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 5.h),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20.r),
                border: Border.all(
                  color: const Color(0xFF9B9B9B),
                  width: 0.5.w,
                ),
              ),
              child: Row(
                children: [
                  Image.asset(
                    'assets/scheme_images/need_help.png',
                    width: 16.w,
                    height: 16.h,
                  ),
                  SizedBox(width: 4.w),
                  TrText(
                    'Need Help ?',
                    style: TextStyle(
                      color: AppColors.primaryColor,
                      fontSize: 12.sp,
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(width: 10.w),
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const NotificationScreen(),
                ),
              );
            },
            child: Image.asset(
              'assets/home_images/notification.png',
              width: 24.w,
              height: 24.h,
            ),
          ),
          SizedBox(width: 16.w),
        ],
    );
  }

  // ---------------------------- AUCTION DETAILS CARD ----------------------------
  Widget _buildAuctionDetailsCard() {
    String auctionDate = '-';
    String auctionTime = '-';
    
    if (_apiData != null && _apiData!['group'] != null) {
      if (_apiData!['group']['sdate'] != null) {
        try {
          auctionDate = _formatDate(DateTime.parse(_apiData!['group']['sdate']));
        } catch (_) {
          auctionDate = _apiData!['group']['sdate'].toString();
        }
      }
      if (_apiData!['group']['atime'] != null) {
        auctionTime = _apiData!['group']['atime'].toString();
      }
    }

    return Container(
          padding: EdgeInsets.all(16.w),
          decoration: BoxDecoration(
            color: const Color(0xFFE2EDF8),
            border: Border.all(color: Color(0xFFF1F5F9)), // Light blue grey
            borderRadius: BorderRadius.circular(12.r),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Image.asset(
                    'assets/home_images/auction.png',
                    width: 25.w,
                    height: 25.w,
                  ),
                  SizedBox(width: 10.w),
                  TrText(
                    'Auction Details',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 12.sp,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
              Divider(color: Color(0xFFCDD2DA), thickness: 0.7),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TrText(
                          'Auction Date',
                          style: TextStyle(
                            color: Color(0xFF505255),
                            fontSize: 10.sp,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(height: 4.h),
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          alignment: Alignment.centerLeft,
                          child: Text(
                            auctionDate,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 12.sp,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(width: 1, height: 30.h, color: Color(0xFFCDD2DA)),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        TrText(
                          'Auction No.',
                          style: TextStyle(
                            color: Color(0xFF505255),
                            fontSize: 10.sp,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(height: 4.h),
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(
                            _apiData?['chit_id']?.toString() ?? '-',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 12.sp,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(width: 1, height: 30.h, color: Color(0xFFCDD2DA)),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        TrText(
                          'Auction Time',
                          style: TextStyle(
                            color: Color(0xFF505255),
                            fontSize: 10.sp,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(height: 4.h),
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          alignment: Alignment.centerRight,
                          child: Text(
                            auctionTime,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 12.sp,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
  }

  Widget _buildRunningBalanceCard() {
    double rb = widget.lastAuctionAmount;
    if (_apiData != null && _apiData!['running_balance'] != null) {
      rb = double.tryParse(_apiData!['running_balance'].toString()) ?? widget.lastAuctionAmount;
    }

    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
      decoration: BoxDecoration(
        color: const Color(0xFFD9AB07), // gold
        borderRadius: BorderRadius.circular(8.r),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: EdgeInsets.all(6.w),
            decoration: const BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
            ),
            child: Image.asset(
              'assets/home_images/coin_plant.png',
              width: 24.w,
              height: 24.w,
            ),
          ),
          SizedBox(width: 10.w),
          Flexible(
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: TrText(
                'RUNNING BALANCE ',
                style: TextStyle(
                  fontFamily: 'Inter',
                  fontWeight: FontWeight.w500,
                  fontSize: 14.sp,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          SizedBox(width: 4.w),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              '₹ ${_formatAmount(rb)}',
              style: TextStyle(
                fontFamily: 'Inter',
                fontWeight: FontWeight.bold,
                fontSize: 18.sp,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------- COUNTDOWN ----------------------------
  Widget _buildCountdownRow() {
    final days = _remaining.inDays.toString().padLeft(2, '0');
    final hours = _remaining.inHours.remainder(24).toString().padLeft(2, '0');
    final mins = _remaining.inMinutes.remainder(60).toString().padLeft(2, '0');
    final secs = _remaining.inSeconds.remainder(60).toString().padLeft(2, '0');

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _TimerBox(value: days, label: 'DAYS'),
        _timerSeparator(),
        _TimerBox(value: hours, label: 'HOURS'),
        _timerSeparator(),
        _TimerBox(value: mins, label: 'MINS'),
        _timerSeparator(),
        _TimerBox(value: secs, label: 'SECS'),
      ],
    );
  }

  Widget _timerSeparator() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 8.w),
      child: Text(
        ':',
        style: TextStyle(
          fontFamily: 'Manrope',
          fontWeight: FontWeight.w800,
          fontSize: 24.22.sp,
          color: kAmountGreen,
        ),
      ),
    );
  }

  // ---------------------------- AMOUNT INPUT ----------------------------
  Widget _buildAmountInput() {
    return Container(
      width: double.infinity,
      height: 40.h,
      padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 16.w),
      decoration: BoxDecoration(
        color: kInputBg,
        borderRadius: BorderRadius.circular(7.28.r),
        border: Border.all(color: kInputBorder, width: 1.82),
      ),
      child: Row(
        children: [
          Text(
            '₹',
            style: TextStyle(
              fontFamily: 'Inter',
              fontWeight: FontWeight.w600,
              fontSize: 18.sp,
              color: kHeadingDark,
            ),
          ),
          Expanded(
            child: TextField(
              controller: _amountController,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.right,
              decoration: const InputDecoration(
                border: InputBorder.none,
                isDense: true,
                contentPadding: EdgeInsets.zero,
              ),
              style: TextStyle(
                fontFamily: 'Inter',
                fontWeight: FontWeight.w600,
                fontSize: 18.21.sp,
                color: kHeadingDark,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ---------------------------- TERMS CARD ----------------------------
  // Exact spec: 324 x 74.21, radius 10.86, border 0.91 #D0C6AB, bg #FFFFFF.
  Widget _buildTermsCard(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      decoration: BoxDecoration(
        color: kTermsCardBg,
        borderRadius: BorderRadius.circular(10.r),
        border: Border.all(color: kTermsCardBorder, width: 0.91),
      ),
      child: Row(
        children: [
          // Checkbox — 19.91 x 19.91, radius 3.62, bg #018F46, border 0.91 #000000.
          GestureDetector(
            onTap: () => setState(() => _agreedToTerms = !_agreedToTerms),
            child: Container(
              width: 16.w,
              height: 15.h,
              decoration: BoxDecoration(
                color: _agreedToTerms ? kCheckboxGreen : Colors.white,
                borderRadius: BorderRadius.circular(3.r),
                border: Border.all(
                  color: _agreedToTerms ? Colors.transparent : Colors.black,
                  width: 0.5,
                ),
              ),
              alignment: Alignment.center,
              child: _agreedToTerms
                  ? Icon(
                      Icons.check,
                      size: 16.sp,
                      color: Colors.white,
                    )
                  : null,
            ),
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: GestureDetector(
              onTap: () => _openTermsAndConditions(context),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TrText('I have read and agree to the', 
                  style: TextStyle(
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w400,
                        fontStyle: FontStyle.normal,
                        fontSize: 14.sp,
                        color: Colors.black87,
                      ),
                  ),
                  SizedBox(height: 4.h),
                  TrText('Pre-Bidding Terms & Conditions', 
                  style: TextStyle(
                        fontFamily: 'Inter',
                        fontWeight: FontWeight.w400,
                        fontSize: 14.sp,
                        color: kAmountGreen,
                      ),)
                ],
              ),
            ),
          ),
          GestureDetector(
            onTap: () => _openTermsAndConditions(context),
            child: Padding(
              padding: EdgeInsets.only(left: 8.w),
              child: Icon(
                Icons.chevron_right,
                size: 24.sp,
                color: kAmountGreen,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _openTermsAndConditions(BuildContext context) {
    if (_amountController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: TrText('Please enter bid amount', style: TextStyle(color: Colors.white)),
          backgroundColor: Colors.black,
          behavior: SnackBarBehavior.fixed,
        ),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => TermsAndConditionsScreen(
        chitId: widget.chitId,
        amount: _amountController.text.trim(),
        groupName: widget.groupCode,
        bidderName: _bidderName,
      )),
    );
  }
}

class _TimerBox extends StatelessWidget {
  final String value;
  final String label;
  const _TimerBox({required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.fromLTRB(8.07.w, 3.53.h, 8.07.w, 7.57.h),
          decoration: BoxDecoration(
            color: kTimerBoxBg,
            borderRadius: BorderRadius.circular(8.07.r),
            border: Border.all(
              color: kTimerBoxBorder.withValues(alpha: 0.2),
              width: 1.01,
            ),
          ),
          child: Text(
            value,
            style: TextStyle(
              fontFamily: 'Manrope',
              fontWeight: FontWeight.w800,
              fontSize: 24.22.sp,
              height: 1.0,
              letterSpacing: -0.61,
              color: Colors.white,
            ),
          ),
        ),
        SizedBox(height: 6.h),
        FittedBox(
          fit: BoxFit.scaleDown,
          child: TrText(
            label,
            style: TextStyle(
              fontFamily: 'Manrope',
              fontWeight: FontWeight.w700,
              fontSize: 9.08.sp,
              height: 13.62 / 9.08,
              letterSpacing: 0.45,
              color: kAmountGreen,
            ),
          ),
        ),
      ],
    );
  }
}

